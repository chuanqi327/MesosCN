#!/bin/bash
/usr/sbin/mesos-slave --master=$MESOS_ZK --log_dir=$MESOS_LOG_DIR --containerizers=$MESOS_CONTAINERIZERS --executor_registration_timeout=$TIMEOUT --hostname=$MESOS_HOSTNAME --ip=$MESOS_IP --isolation=$ISOLATION
